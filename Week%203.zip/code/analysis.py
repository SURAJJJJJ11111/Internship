from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "visualizations"
OUT.mkdir(exist_ok=True)

# Load the included synthetic demonstration data.
# Replace with a cited public dataset for empirical conclusions.
df = pd.read_csv(DATA / "tourism_demo_dataset.csv", parse_dates=["month"])
df.groupby("destination")["interest_index"].mean().plot(kind="bar")
plt.tight_layout(); plt.savefig(OUT / "destination_bar.png"); plt.close()
df.groupby("month")["interest_index"].mean().plot(kind="line")
plt.tight_layout(); plt.savefig(OUT / "monthly_line.png"); plt.close()
plt.scatter(df["interest_index"], df["engagement_score"])
plt.tight_layout(); plt.savefig(OUT / "interest_engagement_scatter.png"); plt.close()
