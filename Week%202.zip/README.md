# Week 2: Data Cleaning and Preprocessing for Tourism Data

This report documents a reproducible data-cleaning workflow for tourism-related data. It covers schema inspection, missing-value handling, duplicate detection, inconsistent category labels, invalid values, and before/after comparisons. The data supplied in this package is synthetic demonstration data, not an official public dataset; replace it with a documented public source before making real-world claims.

## Run
Install requirements with `pip install -r requirements.txt`, then run `python code/analysis.py`.

**Important:** included data is synthetic demonstration data, not official tourism observations. Replace with documented public data for final empirical submission.
