from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "visualizations"
OUT.mkdir(exist_ok=True)

# Load the included synthetic demonstration data.
# Replace with a cited public dataset for empirical conclusions.
df = pd.read_csv(DATA / "tourism_raw_dirty_demo.csv")
print("Before:", df.shape, "missing cells:", int(df.isna().sum().sum()))
df["destination"] = df["destination"].astype("string").str.strip().str.title()
df["month"] = pd.to_datetime(df["month"], errors="coerce")
df = df.drop_duplicates()
df["interest_index"] = pd.to_numeric(df["interest_index"], errors="coerce")
df.loc[df["interest_index"] < 0, "interest_index"] = float("nan")
df["interest_index"] = df["interest_index"].fillna(
    df.groupby("destination")["interest_index"].transform("median"))
df["region"] = df["region"].fillna("Unknown")
print("After:", df.shape, "missing cells:", int(df.isna().sum().sum()))
df.to_csv(DATA / "tourism_cleaned_demo.csv", index=False)
