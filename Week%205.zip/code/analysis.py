from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "visualizations"
OUT.mkdir(exist_ok=True)

# Load the included synthetic demonstration data.
# Replace with a cited public dataset for empirical conclusions.
import re
df = pd.read_csv(DATA / "synthetic_tourist_feedback.csv")
positive = {"immersive","easy","beautiful","loved","helpful","clear","amazing","recommended","good","smooth","interesting","enjoyable","informative"}
negative = {"confusing","freezing","slowly","repetitive","difficult","improved","work"}
def clean_tokens(text):
    return re.findall(r"[a-z]+", str(text).lower())
def sentiment(text):
    words = clean_tokens(text)
    score = sum(w in positive for w in words) - sum(w in negative for w in words)
    return score
df["sentiment_score"] = df["review_text"].apply(sentiment)
df["sentiment"] = df["sentiment_score"].apply(lambda s: "Positive" if s>0 else ("Negative" if s<0 else "Neutral"))
print(df[["review_text","sentiment_score","sentiment"]])
