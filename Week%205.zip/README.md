# Week 5: Social Media and Sentiment Analysis for Tourist Feedback

This report demonstrates a text-analysis workflow for tourism feedback, including text cleaning, tokenization, sentiment scoring, sentiment distribution visualization, and interpretation for service improvement. The included reviews are synthetic examples, not real social media posts or customer reviews. For empirical conclusions, use a permitted public review dataset and document its provenance and usage conditions.

## Run
Install requirements with `pip install -r requirements.txt`, then run `python code/analysis.py`.

**Important:** included data is synthetic demonstration data, not official tourism observations. Replace with documented public data for final empirical submission.
