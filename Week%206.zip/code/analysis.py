from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "visualizations"
OUT.mkdir(exist_ok=True)

# Load the included synthetic demonstration data.
# Replace with a cited public dataset for empirical conclusions.
df = pd.read_csv(DATA / "tourism_demo_dataset.csv", parse_dates=["month"])
print(df.groupby("destination")["interest_index"].agg(["mean","median","std","count"]))
print(df.groupby("month")["interest_index"].mean().tail(12))
# Combine verified results from cleaning, visualization, forecasting, and sentiment work.
# Do not present synthetic demo outputs as real-world evidence.
