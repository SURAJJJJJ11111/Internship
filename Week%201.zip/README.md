# Week 1 — Exploratory Data Analysis in Virtual Tourism Trends

## Package contents
- `data/virtual_tourism_illustrative_dataset.csv`: synthetic example data (not official tourism observations).
- `code/run_eda.py`: reproducible EDA script.
- `visualizations/`: four sample charts included in the report.
- `requirements.txt`: Python dependencies.

## Important data note
The CSV is synthetic and is included to demonstrate the workflow. It must not be described as a public/official dataset. The assignment asks for publicly available data; for a fully empirical final submission, download a dataset from a public source such as:
- UN Tourism data portal: https://www.unwto.org/tourism-data
- World Bank World Development Indicators / international tourism indicators: https://data.worldbank.org/
- Our World in Data (tourism-related datasets where available): https://ourworldindata.org/
Then replace the bundled CSV and adapt the column names in `code/run_eda.py`.

## Run
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Run: `pip install -r requirements.txt`
4. Run: `python code/run_eda.py`

The included figures and report findings are explicitly illustrative, not real-world conclusions.
