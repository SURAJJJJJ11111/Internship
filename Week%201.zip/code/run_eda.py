"""
Week 1: Exploratory Data Analysis in Virtual Tourism Trends
Reproducible workflow for the included illustrative dataset.

IMPORTANT:
The bundled CSV is synthetic/demo data created for demonstrating EDA workflow.
It is NOT an official public tourism dataset and results must not be represented
as real-world tourism findings. For a fully empirical submission, replace it
with a public dataset (suggestions in README) and rerun this script.
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "virtual_tourism_illustrative_dataset.csv"
OUT = ROOT / "visualizations"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA)
print("Shape:", df.shape)
print("\nMissing values:\n", df.isna().sum())
print("\nDescriptive statistics:\n", df.describe(include="all"))
print("\nAverage interest by destination:\n",
      df.groupby("destination")["virtual_tourism_interest_index"].mean().sort_values(ascending=False))
print("\nAverage interest by region:\n",
      df.groupby("visitor_region")["virtual_tourism_interest_index"].mean().sort_values(ascending=False))

df["month"] = pd.to_datetime(df["month"], errors="coerce")
df = df.drop_duplicates()
df = df.dropna(subset=["month", "destination", "virtual_tourism_interest_index"])
df["virtual_tourism_interest_index"] = pd.to_numeric(
    df["virtual_tourism_interest_index"], errors="coerce"
)
df = df.dropna(subset=["virtual_tourism_interest_index"])

(df.groupby("destination")["virtual_tourism_interest_index"].mean()
   .sort_values().plot(kind="bar", title="Average Interest Index by Destination"))
plt.ylabel("Illustrative interest index")
plt.tight_layout()
plt.savefig(OUT / "01_destination_interest_bar.png", dpi=160)
plt.close()

(df.groupby("month")["virtual_tourism_interest_index"].mean()
   .plot(kind="line", marker="o", title="Monthly Interest Index"))
plt.ylabel("Illustrative interest index")
plt.tight_layout()
plt.savefig(OUT / "02_monthly_trend_line.png", dpi=160)
plt.close()

plt.scatter(df["virtual_tourism_interest_index"], df["engagement_score"], alpha=0.6)
plt.title("Interest Index vs Engagement")
plt.xlabel("Illustrative interest index")
plt.ylabel("Engagement score")
plt.tight_layout()
plt.savefig(OUT / "03_interest_engagement_scatter.png", dpi=160)
plt.close()

print("\\nDone. Figures saved to:", OUT)
