from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "visualizations"
OUT.mkdir(exist_ok=True)

# Load the included synthetic demonstration data.
# Replace with a cited public dataset for empirical conclusions.
import numpy as np
df = pd.read_csv(DATA / "tourism_demo_dataset.csv", parse_dates=["month"])
ts = df.groupby("month")["interest_index"].mean().reset_index()
ts["lag1"] = ts["interest_index"].shift(1)
ts = ts.dropna()
split = int(len(ts) * 0.8)  # chronological split; no shuffling
train, test = ts.iloc[:split], ts.iloc[split:]
pred = test["lag1"].to_numpy()  # naive lag-1 baseline
actual = test["interest_index"].to_numpy()
mae = np.mean(np.abs(actual - pred))
rmse = np.sqrt(np.mean((actual - pred) ** 2))
print("MAE:", mae, "RMSE:", rmse)
plt.plot(test["month"], actual, label="Actual")
plt.plot(test["month"], pred, label="Predicted")
plt.legend(); plt.tight_layout(); plt.savefig(OUT / "actual_vs_predicted.png")
