# Week 4: Predictive Modeling for Tourism Demand Forecasting

This report demonstrates a time-ordered forecasting workflow using a simple baseline and a machine-learning regression model. It explains target selection, chronological train/test splitting, lag features, evaluation with MAE and RMSE, actual-versus-predicted visualization, and limitations. All values are synthetic demonstration data; model scores must not be interpreted as real tourism forecasting performance.

## Run
Install requirements with `pip install -r requirements.txt`, then run `python code/analysis.py`.

**Important:** included data is synthetic demonstration data, not official tourism observations. Replace with documented public data for final empirical submission.
